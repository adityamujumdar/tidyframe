#!/usr/bin/env python3
"""
Gemini Batch Processing Validation Test
Ensures batch processing efficiency and prevents regression of the cache null check bug.
"""

import pytest
import asyncio
import os
import sys
from pathlib import Path

# Add backend to path
backend_path = Path(__file__).parent.parent
sys.path.insert(0, str(backend_path))

from app.services.gemini_service import ConsolidatedGeminiService


@pytest.mark.asyncio
async def test_gemini_batch_processing_efficiency():
    """
    Test that Gemini batch processing works efficiently without fallback to slow parsing.
    
    This test validates the fix for the critical cache null check bug that was causing:
    - "object of type 'NoneType' has no len()" errors
    - 100% fallback processing instead of efficient Gemini processing
    """
    
    # Test with diverse name patterns to ensure robustness
    test_names = [
        'John Smith',           # Simple person name
        'Sarah Johnson',        # Simple person name  
        'Baker Family Trust',   # Trust entity
        'ABC Farms LLC',        # Company entity
        'Smith John & Mary'     # Joint ownership pattern
    ]
    
    service = ConsolidatedGeminiService()
    result = await service.parse_names_batch(test_names)
    
    # Validate core functionality
    assert result.total_processed == len(test_names), "All names should be processed"
    assert len(result.results) == len(test_names), "Results count should match input count"
    
    # Critical efficiency validation - this was broken before the fix
    gemini_efficiency = result.gemini_used / result.total_processed if result.total_processed > 0 else 0
    
    # With valid API key, expect high Gemini processing rate (80%+)
    # This validates the cache null check fix is working
    if os.getenv('GEMINI_API_KEY') and os.getenv('GEMINI_API_KEY') != '':
        assert gemini_efficiency >= 0.8, f"Expected >=80% Gemini processing, got {gemini_efficiency:.1%}. Cache bug may have regressed."
        assert result.gemini_used > 0, "Should use Gemini processing with valid API key"
        
        # Validate entity classification is working (advanced AI features)
        entity_types = {result.entity_type for result in result.results}
        assert 'person' in entity_types, "Should classify person entities"
        
        # Validate specific complex parsing works
        trust_results = [r for r in result.results if r.parsing_method == 'gemini' and 'trust' in test_names[result.results.index(r)].lower()]
        company_results = [r for r in result.results if r.parsing_method == 'gemini' and 'llc' in test_names[result.results.index(r)].lower()]
        
        print(f"✅ Batch processing efficiency: {gemini_efficiency:.1%} Gemini processing")
        print(f"✅ Entity types detected: {entity_types}")
    else:
        # Without API key, should gracefully fallback
        assert result.fallback_used == result.total_processed, "Should fallback all names without API key"
        print("ℹ️  No API key provided - tested fallback behavior")
    
    # Performance validation - should be fast due to concurrent processing
    assert result.processing_time < 10.0, f"Batch processing should be fast, took {result.processing_time:.2f}s"
    
    # Validate no parsing failures
    for parsed_result in result.results:
        assert parsed_result.parsing_method in ['gemini', 'fallback'], "Should use known parsing methods"
        assert parsed_result.parsing_confidence >= 0.0, "Should have valid confidence score"


def test_gemini_cache_null_handling():
    """
    Test that cache null handling doesn't break service initialization.
    
    This specifically validates the fix for the cache null pointer issue.
    """
    
    # Test with caching disabled (cache = None scenario)
    os.environ['ENABLE_CACHING'] = 'false'
    
    try:
        service = ConsolidatedGeminiService()
        assert service.cache is None, "Cache should be None when disabled"
        assert service.cache_enabled is False, "Caching should be disabled"
        
        # This initialization should not crash (was causing the original bug)
        print("✅ Service initializes correctly with caching disabled")
        
    finally:
        # Restore caching for other tests
        os.environ['ENABLE_CACHING'] = 'true'


if __name__ == "__main__":
    """Run tests directly for development/debugging"""
    
    print("🧪 Running Gemini Batch Processing Validation Tests")
    print("=" * 60)
    
    # Test cache handling
    test_gemini_cache_null_handling()
    
    # Test batch processing efficiency
    asyncio.run(test_gemini_batch_processing_efficiency())
    
    print("=" * 60)
    print("🎉 All tests passed! Batch processing is working efficiently.")