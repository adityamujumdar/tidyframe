#!/usr/bin/env python3
"""Test script to verify Gemini prompt improvements for trust name extraction"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.services.gemini_service import GeminiService
from app.services.fallback_name_parser import FallbackNameParser
import asyncio
import json

# Test cases from user's problematic trust names
TEST_TRUST_NAMES = [
    "Cole Beulah Revocable Trust",
    "Mcculley Phyllis J Trust",
    "Cheslak Family Trust", 
    "Birch Dale F Family Trust",
    "Daake Dennis R. Living Trust",
    "Hamilton/Kim & Robert",
    "Smith John & Mary Trust",
    "Van Der Berg Family Trust",
    "Et Al Johnson Trust",
    "De La Rosa Living Trust"
]

async def test_gemini_extraction():
    """Test Gemini service with updated prompt"""
    print("Testing Gemini Service with Updated Prompt")
    print("=" * 60)
    
    # Initialize service
    gemini_service = GeminiService()
    
    for name in TEST_TRUST_NAMES:
        print(f"\nTesting: {name}")
        try:
            result = await gemini_service.parse_name(name)
            print(f"  Entity Type: {result.get('entity_type', 'N/A')}")
            print(f"  First Name: {result.get('first_name', 'N/A')}")
            print(f"  Last Name: {result.get('last_name', 'N/A')}")
            print(f"  Gender: {result.get('gender', 'N/A')}")
            print(f"  Confidence: {result.get('confidence', 0)}")
            print(f"  Parser: {result.get('parser_type', 'N/A')}")
            
            # Check if extraction meets expectations
            if result.get('entity_type') == 'trust':
                if result.get('first_name') or result.get('last_name'):
                    print("  ✓ Successfully extracted name from trust")
                else:
                    print("  ✗ Failed to extract name from trust")
            
        except Exception as e:
            print(f"  ERROR: {e}")

def test_fallback_extraction():
    """Test fallback parser for comparison"""
    print("\n" + "=" * 60)
    print("Testing Fallback Parser for Comparison")
    print("=" * 60)
    
    parser = FallbackNameParser()
    
    for name in TEST_TRUST_NAMES:
        print(f"\nTesting: {name}")
        result = parser.parse_name(name)
        print(f"  Entity Type: {result.get('entity_type', 'N/A')}")
        print(f"  First Name: {result.get('first_name', 'N/A')}")
        print(f"  Last Name: {result.get('last_name', 'N/A')}")
        print(f"  Is Entity: {result.get('is_entity', False)}")
        print(f"  Confidence: {result.get('confidence', 0)}")

async def main():
    """Run all tests"""
    # Test with Gemini (if API key is configured)
    try:
        await test_gemini_extraction()
    except Exception as e:
        print(f"Gemini testing skipped: {e}")
    
    # Always test fallback
    test_fallback_extraction()
    
    print("\n" + "=" * 60)
    print("Testing Complete")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(main())