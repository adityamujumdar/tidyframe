import{l as c}from"./index-Dm6eGH54.js";/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],t=c("circle-check-big",e);export{t as C};
//# sourceMappingURL=circle-check-big-Cj0iId1M.js.map
