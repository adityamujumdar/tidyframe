import{r as u}from"./router-BpYP0_uS.js";function o(r){const e=u.useRef({value:r,previous:r});return u.useMemo(()=>(e.current.value!==r&&(e.current.previous=e.current.value,e.current.value=r),e.current.previous),[r])}export{o as u};
//# sourceMappingURL=index-CW3Nip_5.js.map
