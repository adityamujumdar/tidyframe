import{j as o}from"./ui-By_2Fhe3.js";import{x as t}from"./index-Dm6eGH54.js";import"./router-BpYP0_uS.js";import"./vendor-9sitkZcQ.js";function p(){return o.jsx(t,{showTitle:!0,compact:!1})}export{p as default};
//# sourceMappingURL=FileUpload--m42X6Gk.js.map
