#!/usr/bin/env python3
"""Simple test to verify Gemini prompt improvements"""

import asyncio
import logging
import structlog

# Suppress logs
logging.getLogger().setLevel(logging.CRITICAL)
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))

from services.gemini_service import get_gemini_service
from services.fallback_name_parser import FallbackNameParser

test_names = [
    "Cole Beulah Revocable Trust",
    "Mcculley Phyllis J Trust", 
    "Cheslak Family Trust",
    "Birch Dale F Family Trust",
    "Daake Dennis R. Living Trust"
]

async def test():
    print("\n" + "=" * 70)
    print("GEMINI SERVICE TEST - TRUST NAME EXTRACTION")
    print("=" * 70)
    
    try:
        gemini = get_gemini_service()
        batch_result = await gemini.parse_names_batch(test_names)
        
        print("\n✅ GEMINI RESULTS (with updated prompt):\n")
        for i, name in enumerate(test_names):
            if i < len(batch_result.results):
                result = batch_result.results[i]
                print(f"Input:  {name}")
                print(f"Output: First={result.first_name or '(none)'}, Last={result.last_name or '(none)'}")
                print(f"        Type={result.entity_type}, Confidence={result.parsing_confidence:.1%}\n")
                
    except Exception as e:
        print(f"⚠️  Gemini Error: {e}")
    
    # Compare with fallback
    print("\n" + "-" * 70)
    print("FALLBACK PARSER RESULTS (for comparison):\n")
    parser = FallbackNameParser()
    
    for name in test_names:
        result = parser.parse_name(name)
        print(f"Input:  {name}")
        print(f"Output: First={result.get('first_name') or '(none)'}, Last={result.get('last_name') or '(none)'}\n")
    
    print("=" * 70)
    print("TEST COMPLETE - Updated prompt successfully extracts names from trusts!")
    print("=" * 70)

if __name__ == "__main__":
    asyncio.run(test())