#!/usr/bin/env python3
"""Test specific failing cases to understand the extraction issues"""

import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import logging
logging.getLogger().setLevel(logging.WARNING)

from app.services.gemini_service import ConsolidatedGeminiService
from app.services.fallback_name_parser import FallbackNameParser

# Exact failing cases from user
FAILING_CASES = [
    # Case 1: Missing first names in trusts
    {"input": "Uhl Judy A Revocable Trust Dated 04/07/2010",
     "expected": {"first": "Judy", "last": "Uhl", "type": "trust"},
     "actual": {"first": "", "last": "Uhl"}},

    {"input": "Kramersmeier Wallace C Trust",
     "expected": {"first": "Wallace", "last": "Kramersmeier", "type": "trust"},
     "actual": {"first": "", "last": "Kramersmeier"}},

    {"input": "Daake Dennis R. Living Trust",
     "expected": {"first": "Dennis", "last": "Daake", "type": "trust"},
     "actual": {"first": "", "last": "Daake"}},

    {"input": "Baker Cleo L Trust",
     "expected": {"first": "Cleo", "last": "Baker", "type": "trust"},
     "actual": {"first": "", "last": "Baker"}},

    # Case 2: Wrong gender prioritization
    {"input": "Glasnapp Wayne R & Maryl Rev Trust",
     "expected": {"first": "Wayne", "last": "Glasnapp", "type": "trust"},
     "actual": {"first": "Maryl", "last": "Glasnapp"}},

    {"input": "Mills Edwin L & Gloria F Rev Trs Tic",
     "expected": {"first": "Edwin", "last": "Mills", "type": "trust"},
     "actual": {"first": "Gloria", "last": "Mills"}},

    # Case 3: Wrong name ordering
    {"input": "Birch Dale F Family Trust",
     "expected": {"first": "Dale", "last": "Birch", "type": "trust"},
     "actual": {"first": "Birch", "last": "Dale"}},

    # Case 4: Complex patterns
    {"input": "Sorenson Idamay Nancy M. Donnell L. &",
     "expected": {"first": "Donnell", "last": "Sorenson", "type": "person"},
     "actual": {"first": "Nancy", "last": "Sorenson"}},

    {"input": "Gifford Roseann - 1/2",
     "expected": {"first": "Roseann", "last": "Gifford", "type": "person"},
     "actual": {"first": "", "last": "Gifford"}},
]

async def test_extraction():
    """Test extraction with both services"""
    gemini = ConsolidatedGeminiService()
    fallback = FallbackNameParser()

    print("\n" + "="*80)
    print("ANALYZING EXTRACTION FAILURES")
    print("="*80)

    # Test each case
    test_inputs = [case["input"] for case in FAILING_CASES]

    # Try Gemini
    print("\n🤖 Testing with Gemini API...")
    try:
        batch_result = await gemini.parse_names_batch(test_inputs)
        if hasattr(batch_result, 'results'):
            gemini_results = batch_result.results
        else:
            gemini_results = []
    except Exception as e:
        print(f"❌ Gemini failed: {e}")
        gemini_results = []

    # Test with fallback
    print("🔄 Testing with Fallback Parser...")
    fallback_results = []
    for name in test_inputs:
        result = fallback.parse_name(name)
        fallback_results.append(result)

    # Analyze results
    print("\n" + "="*80)
    print("DETAILED ANALYSIS")
    print("="*80)

    for i, case in enumerate(FAILING_CASES):
        print(f"\n[{i+1}] INPUT: {case['input']}")
        print(f"    EXPECTED: First={case['expected']['first']}, Last={case['expected']['last']}")

        if i < len(gemini_results):
            g = gemini_results[i]
            g_first = g.get('first_name', '') if isinstance(g, dict) else getattr(g, 'first_name', '')
            g_last = g.get('last_name', '') if isinstance(g, dict) else getattr(g, 'last_name', '')
            g_type = g.get('entity_type', '') if isinstance(g, dict) else getattr(g, 'entity_type', '')

            match_first = g_first == case['expected']['first']
            match_last = g_last == case['expected']['last']

            print(f"    GEMINI:   First={g_first or '(none)'}, Last={g_last or '(none)'}", end="")
            if match_first and match_last:
                print(" ✅")
            else:
                print(" ❌")
                if not match_first:
                    print(f"              → First name wrong: got '{g_first}', expected '{case['expected']['first']}'")
                if not match_last:
                    print(f"              → Last name wrong: got '{g_last}', expected '{case['expected']['last']}'")

        if i < len(fallback_results):
            f = fallback_results[i]
            f_first = f.get('first_name', '')
            f_last = f.get('last_name', '')

            match_first = f_first == case['expected']['first']
            match_last = f_last == case['expected']['last']

            print(f"    FALLBACK: First={f_first or '(none)'}, Last={f_last or '(none)'}", end="")
            if match_first and match_last:
                print(" ✅")
            else:
                print(" ❌")

async def analyze_extraction_logic():
    """Analyze what the extraction is actually doing"""
    print("\n" + "="*80)
    print("EXTRACTION LOGIC ANALYSIS")
    print("="*80)

    # Test simple patterns to understand behavior
    test_patterns = [
        "Smith John Trust",        # Simple [Last] [First] Trust
        "John Smith Trust",        # Simple [First] [Last] Trust
        "Smith John",              # Person - which order?
        "Wayne & Gloria Trust",    # Male prioritization test
        "Family Trust Smith",      # Family trust pattern
        "Smith Family Trust",      # Family trust pattern
    ]

    gemini = ConsolidatedGeminiService()

    try:
        batch_result = await gemini.parse_names_batch(test_patterns)
        if hasattr(batch_result, 'results'):
            results = batch_result.results

            print("\nPattern Testing:")
            for i, pattern in enumerate(test_patterns):
                if i < len(results):
                    r = results[i]
                    first = r.get('first_name', '') if isinstance(r, dict) else getattr(r, 'first_name', '')
                    last = r.get('last_name', '') if isinstance(r, dict) else getattr(r, 'last_name', '')
                    entity = r.get('entity_type', '') if isinstance(r, dict) else getattr(r, 'entity_type', '')

                    print(f"  '{pattern}' → First={first or '(none)'}, Last={last or '(none)'}, Type={entity}")
    except Exception as e:
        print(f"❌ Test failed: {e}")

def identify_root_causes():
    """Identify the root causes of failures"""
    print("\n" + "="*80)
    print("ROOT CAUSE ANALYSIS")
    print("="*80)

    print("""
PATTERN OBSERVED:
1. For patterns like "Uhl Judy A Trust":
   - Gemini sees: ["Uhl", "Judy", "A", "Trust"]
   - Step 2 removes: "A" (initial), "Trust" (entity marker)
   - Left with: ["Uhl", "Judy"]
   - BUT THEN: Only "Uhl" appears in output

   HYPOTHESIS: The prompt says to extract names, but Gemini is only taking the FIRST word
   as the last name when it sees [Word1] [Word2] pattern and ignoring Word2.

2. For gender prioritization:
   - "Wayne & Gloria" should prioritize Wayne (male)
   - But Gloria is being selected

   HYPOTHESIS: Step 5 (gender prioritization) isn't being applied correctly.
   The prompt mentions it but doesn't enforce it strongly enough.

3. For name ordering:
   - "Birch Dale" is being interpreted as First=Birch, Last=Dale
   - Should be First=Dale, Last=Birch

   HYPOTHESIS: The scoring algorithm in Step 3 isn't being executed properly.
   Gemini is defaulting to first word = first name, second word = last name.

CORE ISSUE:
The prompt is too complex (14,000+ characters) and Gemini is:
1. Not following all the steps
2. Taking shortcuts
3. Defaulting to simple patterns instead of the complex scoring
""")

async def main():
    """Run all tests"""
    await test_extraction()
    await analyze_extraction_logic()
    identify_root_causes()

    print("\n" + "="*80)
    print("RECOMMENDATIONS")
    print("="*80)
    print("""
The prompt needs to be RESTRUCTURED, not just tweaked:

1. ENFORCE extraction of ALL name words
   - Currently saying "extract names" but Gemini only takes some
   - Need explicit: "Extract ALL capitalized words that could be names"

2. SIMPLIFY the ordering algorithm
   - Current scoring system (lines 170-217) is being ignored
   - Use simple pattern matching with clear examples

3. STRENGTHEN gender prioritization
   - Currently mentioned but not enforced
   - Make it a MANDATORY step with clear rules

4. REDUCE complexity
   - 400 lines is too much for Gemini to follow reliably
   - Focus on the critical patterns that cover 90% of cases
""")

if __name__ == "__main__":
    asyncio.run(main())