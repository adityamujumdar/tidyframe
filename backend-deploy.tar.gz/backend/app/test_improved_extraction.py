#!/usr/bin/env python3
"""Test improved name extraction with new algorithm"""

import asyncio
import logging
import structlog

# Suppress logs for clean output
logging.getLogger().setLevel(logging.CRITICAL)
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))

from services.gemini_service import get_gemini_service
from services.fallback_name_parser import FallbackNameParser

# Test cases that were problematic
test_cases = [
    ("Cole Beulah Revocable Trust", "Cole", "Beulah"),  # Should be First=Cole, Last=Beulah
    ("Birch Dale F Family Trust", "Dale", "Birch"),      # Should be First=Dale, Last=Birch
    ("Mcculley Phyllis J Trust", "Phyllis", "Mcculley"), # Should be First=Phyllis, Last=Mcculley
    ("Cheslak Family Trust", "", "Cheslak"),             # Should be Last=Cheslak only
    ("Daake Dennis R. Living Trust", "Dennis", "Daake"), # Should be First=Dennis, Last=Daake
    ("Hansen Linda K Rev Trust", "Linda", "Hansen"),     # Should be First=Linda, Last=Hansen
]

async def test():
    print("\n" + "=" * 80)
    print("TESTING IMPROVED NAME EXTRACTION ALGORITHM")
    print("=" * 80)
    
    # Test with Gemini
    print("\n📊 GEMINI SERVICE RESULTS (with improved algorithm):")
    print("-" * 80)
    
    try:
        gemini = get_gemini_service()
        names_only = [case[0] for case in test_cases]
        batch_result = await gemini.parse_names_batch(names_only)
        
        all_correct = True
        for i, (input_name, expected_first, expected_last) in enumerate(test_cases):
            if i < len(batch_result.results):
                result = batch_result.results[i]
                extracted_first = result.first_name or ""
                extracted_last = result.last_name or ""
                
                correct = (extracted_first == expected_first and extracted_last == expected_last)
                status = "✅" if correct else "❌"
                if not correct:
                    all_correct = False
                
                print(f"\n{status} {input_name}")
                print(f"   Expected: First={expected_first or '(none)'}, Last={expected_last or '(none)'}")
                print(f"   Got:      First={extracted_first or '(none)'}, Last={extracted_last or '(none)'}")
                
    except Exception as e:
        print(f"⚠️  Gemini Error: {e}")
        all_correct = False
    
    # Test with Fallback Parser
    print("\n\n📊 FALLBACK PARSER RESULTS (with improved algorithm):")
    print("-" * 80)
    
    parser = FallbackNameParser()
    fallback_correct = True
    
    for input_name, expected_first, expected_last in test_cases:
        result = parser.parse_name(input_name)
        extracted_first = result.get('first_name', '')
        extracted_last = result.get('last_name', '')
        
        correct = (extracted_first == expected_first and extracted_last == expected_last)
        status = "✅" if correct else "❌"
        if not correct:
            fallback_correct = False
        
        print(f"\n{status} {input_name}")
        print(f"   Expected: First={expected_first or '(none)'}, Last={expected_last or '(none)'}")
        print(f"   Got:      First={extracted_first or '(none)'}, Last={extracted_last or '(none)'}")
    
    # Summary
    print("\n" + "=" * 80)
    print("RESULTS SUMMARY")
    print("=" * 80)
    
    if all_correct and fallback_correct:
        print("✅ ALL TESTS PASSED! Name extraction is now working correctly.")
    else:
        print("❌ Some tests failed. Further improvements needed.")
        if not all_correct:
            print("   - Gemini service needs adjustment")
        if not fallback_correct:
            print("   - Fallback parser needs adjustment")
    
    print("=" * 80)

if __name__ == "__main__":
    asyncio.run(test())