#!/usr/bin/env python3
"""Test prompt performance on actual CSV samples"""

import csv
import random
import asyncio
import logging
import structlog

# Suppress logs
logging.getLogger().setLevel(logging.CRITICAL)
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))

from services.gemini_service import get_gemini_service
from services.fallback_name_parser import FallbackNameParser

# Representative test samples from CSV analysis
test_samples = [
    # Trusts with varying patterns
    "Cole Beulah Revocable Trust",
    "Daake Dennis R. Living Trust", 
    "Cheslak Family Trust",
    "Birch Dale F Family Trust",
    "Hansen Linda K Rev Trust",
    "Petersen 2012 Family Trust Gary B. &",
    "Uhl Judy A Revocable Trust Dated 04/07/2010",
    
    # Companies
    "Dickinson Farms Llc",
    "Frei Farms Inc. (deed)",
    "Microsoft Corporation",
    
    # Joint ownership
    "Clark Jason R & Shari A",
    "Botcher Lavern W & Alice E",
    "Mills Edwin L & Gloria F Rev Trs Tic",
    
    # Et Al patterns
    "Roberts Sandra K Etal",
    "Campbell Marvin Dale & Mary Catherine Trs & Etals",
    
    # Complex patterns
    "Bertsch Gregory G.",
    "Cleveringa Marjorie K",
    "Flynn Thomas J/Doyle Cynthia J/Entrust Freedom Llc Fbo Cynthia J Doyle",
    
    # Simple two-word names
    "Graham Shanda",
    "Crim Dale",
    "Switzer Mary",
    
    # Compound surnames
    "Van Diest Family Llc",
    "Mc Laughlin Nita J",
    
    # Life estates
    "Smith Patricia Life Estate",
    "Wichman Jeanine J Le & Rem Kristin Waldrop 1/2"
]

async def test_prompt_on_samples():
    print("\n" + "=" * 80)
    print("TESTING PROMPT ON REAL CSV SAMPLES")
    print("=" * 80)
    
    # Test with Fallback Parser
    print("\n📊 FALLBACK PARSER RESULTS:")
    print("-" * 60)
    
    parser = FallbackNameParser()
    fallback_results = []
    
    for name in test_samples:
        result = parser.parse_name(name)
        first = result.get('first_name', '')
        last = result.get('last_name', '')
        entity_type = result.get('entity_type', 'unknown')
        
        fallback_results.append({
            'input': name,
            'first': first,
            'last': last,
            'type': entity_type
        })
        
        print(f"\n{name}")
        print(f"  → Type: {entity_type}")
        if first or last:
            print(f"  → Name: {first} {last}".strip())
    
    # Test with Gemini
    print("\n\n📊 GEMINI SERVICE RESULTS (Batch):")
    print("-" * 60)
    
    try:
        gemini = get_gemini_service()
        batch_result = await gemini.parse_names_batch(test_samples)
        
        gemini_results = []
        for i, name in enumerate(test_samples):
            if i < len(batch_result.results):
                result = batch_result.results[i]
                print(f"\n{name}")
                print(f"  → Type: {result.entity_type}")
                if result.first_name or result.last_name:
                    print(f"  → Name: {result.first_name or ''} {result.last_name or ''}".strip())
                print(f"  → Confidence: {result.parsing_confidence:.1%}")
                
                gemini_results.append({
                    'input': name,
                    'first': result.first_name or '',
                    'last': result.last_name or '',
                    'type': result.entity_type,
                    'confidence': result.parsing_confidence
                })
                
    except Exception as e:
        print(f"\n⚠️ Gemini Error: {e}")
        gemini_results = []
    
    # Analysis
    print("\n\n📈 PATTERN PERFORMANCE ANALYSIS")
    print("=" * 80)
    
    categories = {
        'Trusts': ['Trust', 'trust', 'Rev', 'Living', 'Dated'],
        'Companies': ['Llc', 'Inc', 'Corp', 'Corporation'],
        'Joint': ['&', '/'],
        'Et Al': ['Etal', 'Et Al', 'Etals'],
        'Simple Names': []  # Will check by pattern
    }
    
    for category, markers in categories.items():
        matching = []
        for result in fallback_results:
            name = result['input']
            if markers and any(m in name for m in markers):
                matching.append(result)
            elif category == 'Simple Names' and len(name.split()) == 2 and not any(m in name for cat_markers in categories.values() for m in cat_markers if cat_markers):
                matching.append(result)
        
        if matching:
            success = sum(1 for r in matching if r['first'] or r['last'] or r['type'] in ['trust', 'company'])
            print(f"\n{category}: {success}/{len(matching)} handled correctly")
            if success < len(matching):
                print("  Failed on:")
                for r in matching:
                    if not (r['first'] or r['last'] or r['type'] in ['trust', 'company']):
                        print(f"    - {r['input']}")

test_loop = asyncio.new_event_loop()
asyncio.set_event_loop(test_loop)
test_loop.run_until_complete(test_prompt_on_samples())