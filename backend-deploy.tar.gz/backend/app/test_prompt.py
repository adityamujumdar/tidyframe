#!/usr/bin/env python3
"""Simple test to verify prompt improvements work"""

import asyncio
import os
from services.gemini_service import get_gemini_service
from services.fallback_name_parser import FallbackNameParser

# Test cases from user
test_names = [
    "Cole Beulah Revocable Trust",
    "Mcculley Phyllis J Trust", 
    "Cheslak Family Trust",
    "Birch Dale F Family Trust",
    "Daake Dennis R. Living Trust"
]

async def test():
    print("Testing name extraction with updated prompt\n")
    print("=" * 60)
    
    # Test with Gemini if available
    try:
        gemini = get_gemini_service()
        print("\nTesting with Gemini Service (Updated Prompt):")
        print("-" * 40)
        
        # Process all names in a batch
        batch_result = await gemini.parse_names_batch(test_names)
        
        # Display results
        for i, name in enumerate(test_names):
            print(f"\nName: {name}")
            if i < len(batch_result.results):
                result = batch_result.results[i]
                
                # Show extraction results
                extracted = []
                if result.first_name:
                    extracted.append(f"First: {result.first_name}")
                if result.last_name:
                    extracted.append(f"Last: {result.last_name}")
                if hasattr(result, 'gender') and result.gender:
                    extracted.append(f"Gender: {result.gender}")
                
                if extracted:
                    print(f"  ✓ Extracted: {', '.join(extracted)}")
                else:
                    print(f"  ✗ No names extracted")
                
                print(f"  Type: {result.entity_type if result.entity_type else 'unknown'}")
                print(f"  Confidence: {result.parsing_confidence:.2f}")
            else:
                print(f"  ✗ No result returned")
                
    except Exception as e:
        print(f"Gemini not available: {e}")
    
    # Test fallback parser
    print("\n\nTesting with Fallback Parser:")
    print("-" * 40)
    parser = FallbackNameParser()
    
    for name in test_names:
        print(f"\nName: {name}")
        result = parser.parse_name(name)
        
        # Show extraction results
        extracted = []
        if result.get('first_name'):
            extracted.append(f"First: {result['first_name']}")
        if result.get('last_name'):
            extracted.append(f"Last: {result['last_name']}")
        
        if extracted:
            print(f"  ✓ Extracted: {', '.join(extracted)}")
        else:
            print(f"  ✗ No names extracted")
        
        print(f"  Type: {result.get('entity_type', 'unknown')}")

if __name__ == "__main__":
    asyncio.run(test())