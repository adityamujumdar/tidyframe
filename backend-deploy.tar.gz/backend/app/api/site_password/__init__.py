"""
Site Password API package
"""

from .router import router

__all__ = ["router"]