"""User management API module"""

from .router import router

__all__ = ["router"]