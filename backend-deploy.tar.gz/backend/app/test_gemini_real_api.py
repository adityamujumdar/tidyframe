#!/usr/bin/env python3
"""Test real Gemini API with random CSV samples to identify extraction issues"""

import asyncio
import csv
import random
import os
import sys
import json
from pathlib import Path
from typing import List, Dict, Any, Tuple
import logging
import structlog
from collections import defaultdict, Counter

# Add app to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configure logging to suppress noise
logging.getLogger().setLevel(logging.WARNING)
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.WARNING))

# Import services
from app.services.gemini_service import ConsolidatedGeminiService
from app.services.fallback_name_parser import FallbackNameParser

async def extract_random_samples(csv_files: List[str], total_samples: int = 100) -> List[str]:
    """Extract diverse random samples from CSV files"""
    all_samples = []
    
    for csv_file in csv_files:
        print(f"  Reading {Path(csv_file).name}...")
        with open(csv_file, 'r', encoding='utf-8', errors='ignore') as f:
            reader = csv.reader(f)
            header = next(reader, None)
            if not header:
                continue
            
            # Owner column is usually index 0 (Primary Addressee)
            owner_idx = 0
            if owner_idx == -1:
                continue
            
            # Collect diverse samples
            samples = []
            for row in reader:
                if len(row) > owner_idx and row[owner_idx]:
                    owner = row[owner_idx].strip()
                    # Skip empty or malformed
                    if owner and not owner.startswith('(') and len(owner) > 3:
                        samples.append(owner)
                if len(samples) >= 300:  # Get more for diversity
                    break
            
            all_samples.extend(samples)
    
    # Ensure diversity in selection
    trust_samples = [s for s in all_samples if 'trust' in s.lower()]
    company_samples = [s for s in all_samples if any(m in s.lower() for m in ['llc', 'inc', 'corp', 'ltd', 'company'])]
    person_samples = [s for s in all_samples if not any(m in s.lower() for m in ['trust', 'llc', 'inc', 'corp'])]
    
    # Balance the selection
    selected = []
    if trust_samples:
        selected.extend(random.sample(trust_samples, min(40, len(trust_samples))))
    if company_samples:
        selected.extend(random.sample(company_samples, min(20, len(company_samples))))
    if person_samples:
        selected.extend(random.sample(person_samples, min(40, len(person_samples))))
    
    # Shuffle for random order
    random.shuffle(selected)
    
    return selected[:total_samples]

async def test_gemini_api(samples: List[str]) -> List[Dict]:
    """Test actual Gemini API with samples"""
    gemini = ConsolidatedGeminiService()
    fallback = FallbackNameParser()
    
    results = []
    gemini_failures = 0
    
    print("\n" + "="*80)
    print("TESTING GEMINI API WITH REAL SAMPLES")
    print("="*80)
    
    for i, name in enumerate(samples, 1):
        print(f"\n[{i:3d}/{len(samples)}] {name[:60]}{'...' if len(name) > 60 else ''}")
        
        # Try Gemini API
        extraction_method = "Gemini"
        api_error = None
        
        try:
            # Gemini processes in batches, so we'll process single item
            batch_results = await gemini.parse_names_batch([name])
            if batch_results and len(batch_results) > 0:
                result = batch_results[0]
            else:
                result = {}
        except Exception as e:
            api_error = str(e)[:100]
            gemini_failures += 1
            print(f"  ⚠️ Gemini API failed: {api_error}")
            # Use fallback
            result = fallback.parse_name(name)
            extraction_method = "Fallback"
        
        # Extract data
        first = result.get('first_name', '')
        last = result.get('last_name', '')
        entity_type = result.get('entity_type', 'unknown')
        gender = result.get('gender', 'unknown')
        confidence = result.get('parsing_confidence', 0.0)
        
        # Analyze issues
        issues = analyze_extraction_issues(name, first, last, entity_type)
        
        # Store result
        results.append({
            'input': name,
            'first_name': first,
            'last_name': last,
            'entity_type': entity_type,
            'gender': gender,
            'confidence': confidence,
            'method': extraction_method,
            'api_error': api_error,
            'issues': issues
        })
        
        # Display result
        print(f"  Type: {entity_type:<10} Method: {extraction_method}")
        print(f"  First: {first or '(none)':<20} Last: {last or '(none)'}")
        if issues:
            print(f"  ⚠️ Issues: {', '.join(issues)}")
    
    if gemini_failures > 0:
        print(f"\n⚠️ Gemini API failed {gemini_failures}/{len(samples)} times ({gemini_failures/len(samples)*100:.1f}%)")
    
    return results

def analyze_extraction_issues(input_name: str, first: str, last: str, entity_type: str) -> List[str]:
    """Identify specific issues with extraction"""
    issues = []
    name_lower = input_name.lower()
    
    # Check 1: Trust names not extracted
    if 'trust' in name_lower and entity_type == 'trust':
        if not first and not last:
            issues.append("Trust has no names extracted")
        elif 'family trust' in name_lower and first:
            # Family trusts typically only have last name
            if not last:
                issues.append("Family trust missing last name")
    
    # Check 2: Company misclassification
    company_markers = ['llc', 'inc', 'corp', 'ltd', 'company', 'properties', 'enterprises']
    has_company_marker = any(m in name_lower for m in company_markers)
    
    if has_company_marker and entity_type != 'company':
        issues.append(f"Company misclassified as {entity_type}")
    elif entity_type == 'company' and (first or last):
        issues.append("Company should not have names")
    
    # Check 3: Person extraction issues
    if entity_type == 'person':
        if not first and not last:
            issues.append("Person has no names extracted")
        
        # Check for entity words in names
        if first:
            for word in ['trust', 'llc', 'inc', 'corp']:
                if word in first.lower():
                    issues.append(f"Entity marker '{word}' in first name")
        if last:
            for word in ['trust', 'llc', 'inc', 'corp']:
                if word in last.lower():
                    issues.append(f"Entity marker '{word}' in last name")
    
    # Check 4: Trust with clear names not extracted
    if 'trust' in name_lower:
        words = input_name.split()
        # Remove common trust words
        name_words = [w for w in words if w.lower() not in 
                     ['trust', 'rev', 'revocable', 'living', 'family', 'ttee', 'trs']]
        
        # If we have 2+ clear name words but didn't extract
        if len(name_words) >= 2 and (not first or not last):
            issues.append("Trust has potential names not extracted")
    
    # Check 5: Name order validation (spot check common patterns)
    if first and last:
        # Check for obvious reversals
        common_first_names = ['john', 'mary', 'james', 'linda', 'robert', 'patricia', 
                             'michael', 'jennifer', 'david', 'barbara']
        common_last_names = ['smith', 'johnson', 'williams', 'brown', 'jones', 
                             'davis', 'miller', 'wilson', 'moore', 'taylor']
        
        if first.lower() in common_last_names and last.lower() in common_first_names:
            issues.append("Possible name reversal")
    
    # Check 6: Compound surname handling
    if 'van ' in name_lower or 'mc ' in name_lower or 'mac ' in name_lower:
        if last and not any(prefix in last.lower() for prefix in ['van ', 'mc', 'mac']):
            if any(prefix in first.lower() for prefix in ['van ', 'mc', 'mac']):
                issues.append("Compound surname possibly split")
    
    return issues

def generate_detailed_analysis(results: List[Dict]) -> Dict:
    """Generate comprehensive analysis of results"""
    analysis = {
        'total_samples': len(results),
        'entity_distribution': Counter(),
        'method_distribution': Counter(),
        'issues_by_type': defaultdict(list),
        'extraction_success_rate': {},
        'common_failures': [],
        'confidence_analysis': {}
    }
    
    # Basic distributions
    for r in results:
        analysis['entity_distribution'][r['entity_type']] += 1
        analysis['method_distribution'][r['method']] += 1
        
        # Track issues by entity type
        if r['issues']:
            analysis['issues_by_type'][r['entity_type']].extend(r['issues'])
    
    # Calculate success rates by entity type
    for entity_type in ['person', 'company', 'trust']:
        entity_results = [r for r in results if r['entity_type'] == entity_type]
        if entity_results:
            # Success = has names for person/trust, no names for company
            if entity_type == 'company':
                successful = sum(1 for r in entity_results if not r['first_name'] and not r['last_name'])
            else:
                successful = sum(1 for r in entity_results if r['first_name'] or r['last_name'])
            
            analysis['extraction_success_rate'][entity_type] = {
                'total': len(entity_results),
                'successful': successful,
                'rate': successful / len(entity_results) * 100
            }
    
    # Identify common failure patterns
    issue_counter = Counter()
    for r in results:
        for issue in r['issues']:
            issue_counter[issue] += 1
    
    analysis['common_failures'] = issue_counter.most_common(10)
    
    # Confidence analysis
    confidence_scores = [r['confidence'] for r in results if r['confidence'] > 0]
    if confidence_scores:
        analysis['confidence_analysis'] = {
            'mean': sum(confidence_scores) / len(confidence_scores),
            'min': min(confidence_scores),
            'max': max(confidence_scores),
            'low_confidence_count': sum(1 for c in confidence_scores if c < 0.7)
        }
    
    return analysis

def print_analysis_report(analysis: Dict, results: List[Dict]):
    """Print detailed analysis report"""
    print("\n" + "="*80)
    print("EXTRACTION ANALYSIS REPORT")
    print("="*80)
    
    print(f"\n📊 OVERALL STATISTICS")
    print(f"Total samples tested: {analysis['total_samples']}")
    print(f"Gemini API used: {analysis['method_distribution'].get('Gemini', 0)} times")
    print(f"Fallback used: {analysis['method_distribution'].get('Fallback', 0)} times")
    
    print(f"\n🏢 ENTITY TYPE DISTRIBUTION")
    for entity, count in analysis['entity_distribution'].items():
        pct = count / analysis['total_samples'] * 100
        print(f"  {entity:<10}: {count:3d} ({pct:5.1f}%)")
    
    print(f"\n✅ EXTRACTION SUCCESS RATES")
    for entity_type, stats in analysis['extraction_success_rate'].items():
        print(f"  {entity_type:<10}: {stats['successful']}/{stats['total']} ({stats['rate']:.1f}% success)")
        if entity_type == 'trust' and stats['rate'] < 80:
            print(f"    ⚠️ Low trust extraction rate!")
    
    print(f"\n⚠️ TOP ISSUES FOUND")
    for issue, count in analysis['common_failures']:
        print(f"  {count:3d}x - {issue}")
    
    if analysis['confidence_analysis']:
        print(f"\n📈 CONFIDENCE ANALYSIS")
        conf = analysis['confidence_analysis']
        print(f"  Mean confidence: {conf['mean']:.2f}")
        print(f"  Range: {conf['min']:.2f} - {conf['max']:.2f}")
        print(f"  Low confidence (<0.7): {conf['low_confidence_count']} samples")
    
    # Show specific problematic samples
    print(f"\n❌ PROBLEMATIC SAMPLES")
    
    # Trusts with no names
    trust_no_names = [r for r in results if r['entity_type'] == 'trust' 
                      and not r['first_name'] and not r['last_name']]
    if trust_no_names:
        print(f"\n  Trusts with NO names extracted ({len(trust_no_names)} cases):")
        for r in trust_no_names[:5]:
            print(f"    • {r['input'][:60]}")
    
    # Companies misclassified
    company_issues = [r for r in results if 'Company misclassified' in str(r['issues'])]
    if company_issues:
        print(f"\n  Companies misclassified ({len(company_issues)} cases):")
        for r in company_issues[:5]:
            print(f"    • {r['input'][:60]} → Type: {r['entity_type']}")
    
    # Persons with no names
    person_no_names = [r for r in results if r['entity_type'] == 'person' 
                       and not r['first_name'] and not r['last_name']]
    if person_no_names:
        print(f"\n  Persons with NO names extracted ({len(person_no_names)} cases):")
        for r in person_no_names[:5]:
            print(f"    • {r['input'][:60]}")
    
    # Name reversals
    reversals = [r for r in results if 'reversal' in str(r['issues'])]
    if reversals:
        print(f"\n  Possible name reversals ({len(reversals)} cases):")
        for r in reversals[:5]:
            print(f"    • {r['input'][:40]} → F:{r['first_name']}, L:{r['last_name']}")

def generate_prompt_improvements(analysis: Dict, results: List[Dict]) -> List[str]:
    """Generate specific prompt improvements based on findings"""
    improvements = []
    
    # Check trust extraction rate
    trust_stats = analysis['extraction_success_rate'].get('trust', {})
    if trust_stats.get('rate', 100) < 80:
        improvements.append("""
IMPROVEMENT 1: Enhanced Trust Name Extraction
- Add more aggressive trust marker removal
- Implement fallback extraction when standard parsing fails
- For trusts with only entity markers, scan full text for potential names
- Add pattern: "The [Name] Trust" → extract [Name] as last_name
""")
    
    # Check for company misclassification
    if 'Company misclassified' in str(analysis['common_failures']):
        improvements.append("""
IMPROVEMENT 2: Better Company Detection
- Expand company markers list: holdings, properties, investments, management
- Check for multiple company indicators before classification
- Pattern: If has "LLC" or "Inc" at end, always classify as company
""")
    
    # Check for person extraction issues
    person_stats = analysis['extraction_success_rate'].get('person', {})
    if person_stats.get('rate', 100) < 90:
        improvements.append("""
IMPROVEMENT 3: Perfect Person Name Extraction
- If no entity markers found, MUST extract at least one name
- For single word entities, determine if first or last name based on patterns
- Handle edge cases: initials only, hyphenated names, suffixes (Jr, Sr, III)
""")
    
    # Check for trust names not extracted
    if 'Trust has no names extracted' in str(analysis['common_failures']):
        improvements.append("""
IMPROVEMENT 4: Mandatory Trust Name Extraction
- Rule: If entity_type="trust", MUST attempt name extraction
- Scan for capitalized words before "Trust" marker
- Pattern recognition for "[Lastname] [Firstname] [Initial] Trust"
- If only numbers/dates before "Trust", look for "of [Name]" pattern
""")
    
    # Check confidence levels
    if analysis.get('confidence_analysis', {}).get('low_confidence_count', 0) > 10:
        improvements.append("""
IMPROVEMENT 5: Confidence Calibration
- Increase confidence when clear patterns match
- Decrease confidence floor to 0.5 for truly ambiguous cases
- Add confidence boost for names in standard databases
""")
    
    return improvements

async def main():
    """Main test execution"""
    # CSV files to test
    csv_files = [
        "/app/test_data/IA.csv",
        "/app/test_data/IL.csv",
        "/app/test_data/WI.csv"
    ]
    
    print("📂 LOADING SAMPLES FROM CSV FILES")
    print("="*80)
    samples = await extract_random_samples(csv_files, total_samples=100)
    print(f"✅ Loaded {len(samples)} diverse samples")
    
    # Test with Gemini API
    results = await test_gemini_api(samples)
    
    # Analyze results
    analysis = generate_detailed_analysis(results)
    
    # Print report
    print_analysis_report(analysis, results)
    
    # Generate improvements
    improvements = generate_prompt_improvements(analysis, results)
    
    print("\n" + "="*80)
    print("💡 RECOMMENDED PROMPT IMPROVEMENTS")
    print("="*80)
    
    for improvement in improvements:
        print(improvement)
    
    # Save results for further analysis
    output_file = "/app/gemini_test_results.json"
    with open(output_file, 'w') as f:
        json.dump({
            'samples': results,
            'analysis': {
                'entity_distribution': dict(analysis['entity_distribution']),
                'extraction_success_rate': analysis['extraction_success_rate'],
                'common_failures': analysis['common_failures'],
                'improvements': improvements
            }
        }, f, indent=2)
    
    print(f"\n📁 Full results saved to: {output_file}")
    
    return analysis, results

if __name__ == "__main__":
    asyncio.run(main())